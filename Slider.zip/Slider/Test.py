#!/usr/bin/python
from __future__ import absolute_import, division, print_function, unicode_literals

""" Example showing what can be left out. ESC to quit"""
#import sys
#sys.path.insert(1, '/home/pi/Documents/pi3d-develop/pi3d')
import pi3d
import os

BACKGROUND = (0.5, 0.5, 1.0, 0)
#DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=10, display_config=pi3d.DISPLAY_CONFIG_FULLSCREEN)
#DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=40, w=1000, h=800, use_glx=True)
DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=40, w=1400, h=800)
# Shaders --------------------------------
shader = pi3d.Shader("uv_light")
flatsh = pi3d.Shader("uv_flat")
tracksh = pi3d.Shader("mat_flat")

SHADER = pi3d.Shader("uv_flat")

mykeys = pi3d.Keyboard()

CAMERA=pi3d.Camera.instance()
CAMERA.position((0,0,-50))

sprite = pi3d.ImageSprite("PAD.png", SHADER, w=10.0, h=6.0) # image de la tablette
#sprite = pi3d.ImageSprite("hand.jpg", SHADER, w=10.0, h=6.0) # image de la tablette
sprite.position(14,-7.5,0)

#cadre
lcadre = 0.5*20
hcadre = 0.125*20
cadre = pi3d.Lines(vertices=[[-lcadre/2, -hcadre/2, 0],[-lcadre/2, hcadre/2 , 0],[lcadre/2, hcadre/2, 0],[lcadre/2,-hcadre/2,0],[-lcadre/2, -hcadre/2, 0]],x=0, y=0, z=0, material=(1.0,0.8,0.05),line_width=4)
cadre.position(0,0,-39/20)
cadre.shader = pi3d.Shader("mat_flat")

# Initialisation de la fleche
lfleche = 0.25*20 # largeur de la fleche
hfleche = 0.125*20 # hauteur de la fleche
fleche = pi3d.Lines(vertices=[[0, hfleche/4, 0],[2*lfleche/3, hfleche/4 , 0],[2*lfleche/3, hfleche/2, 0],[lfleche,0,0],[2*lfleche/3, -hfleche/2, 0],[2*lfleche/3, -hfleche/4, 0],[0, -hfleche/4, 0],[0, hfleche/4, 0]],x=0, y=0, z=0, material=(1.0,0.8,0.05),line_width=4)
fleche.position(0.4,0,-39/20)
fleche.shader = pi3d.Shader("uv_flat")

mode=''


while DISPLAY.loop_running():
  
  # Gestion du clavier
  k = mykeys.read()
  if k >-1:
    #print(k)
    if k == 102:    # F : droite
      mode='png'
    elif k == 115:  # S : gauche
      mode=''
    if k == 27:
      mykeys.close()
      DISPLAY.destroy()
      break
  
  fleche.draw()
  cadre.draw()
    
  if mode=='png':
    sprite.draw()
 
  fleche.draw()
  cadre.draw()
