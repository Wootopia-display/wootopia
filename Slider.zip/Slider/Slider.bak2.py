#!/usr/bin/python
from __future__ import absolute_import, division, print_function, unicode_literals

""" Example showing what can be left out. ESC to quit"""
#import sys
#sys.path.insert(1, '/home/pi/Documents/pi3d-develop/pi3d')
import pi3d
import os
import subprocess

subprocess.Popen('xcompmgr', shell=False)

BACKGROUND = (0, 0, 0, 0)
#DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=10, display_config=pi3d.DISPLAY_CONFIG_FULLSCREEN)
#DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=40, w=1000, h=800, use_glx=True)
DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=40, display_config=pi3d.DISPLAY_CONFIG_FULLSCREEN, use_glx=True)
SHADER = pi3d.Shader("uv_flat")

Repertoire='/home/pi/Documents/Slider/Chaussures Hommes-sport'


def transitionMediaBas(etape, maxetape):
  i=0
  for Media in Medias:
    x=(i-current_media)*distance_mediax
    y=-(etape/maxetape)*distance_mediay
    if i == current_media:
      z=-distance_mediaz
    else:
      z=0
    Media.position(x,y,z)
    i=i+1
    
  i=0
  for Media in NextMedias:
    x=(i-next_current_media)*distance_mediax
    y=distance_mediay*(1-etape/maxetape)
    if i == next_current_media:
      z=-distance_mediaz
    else:
      z=0
    Media.position(x,y,z)
    i=i+1
        
def transitionMediaHaut(etape, maxetape):
  i=0
  for Media in Medias:
    x=(i-current_media)*distance_mediax
    y=distance_mediay*(etape/maxetape)
    if i == current_media:
      z=-distance_mediaz
    else:
      z=0
    Media.position(x,y,z)
    i=i+1
    
  i=0
  for Media in NextMedias:
    x=(i-next_current_media)*distance_mediax
    y=distance_mediay*(etape/maxetape - 1)
    if i == next_current_media:
      z=-distance_mediaz
    else:
      z=0
    Media.position(x,y,z)
    i=i+1
        
CMedias = []

class CMedia:
  def __init__(self, cat, souscat, chemin_image):
    self.cat = cat
    self.souscat = souscat
    self.media = pi3d.ImageSprite(chemin_image, shader=SHADER, w=13, h=9.3, x=0, y=0, z=0)

# Chargement de la totalité des médias à partir du fichier media.ini

f = open('/home/pi/Documents/Slider/medias.ini', "r")
for l in f:
  # si la ligne n'est pas vide et son première caractère est différent de [ et de #, alors traiter la ligne
  if (len(l) > 0) and (l[0]!='[') and (l[0]!='#'):
    t = l.split(';')
    images=os.listdir(t[2])
    for image in images:
      #print(t[2] + '/' + image)
      CMedias.append(CMedia(t[0],t[1],t[2]+'/'+image))
    

# Initialisation des categories

categories=[]
for cm in CMedias:
  if not(cm.cat in categories):
    categories.append(cm.cat)
    
print(categories)
nb_cats=len(categories)  

# Initialisation des sous-categories

sous_categories=[]
for categorie in categories:
  souscat=[]
  for cm in CMedias:
    if (cm.cat == categorie):
      if not(cm.souscat in souscat):
        souscat.append(cm.souscat)
  sous_categories.append(souscat)
  
print(sous_categories)

Blur=True
Blur=False
Fog=True

if Blur:
  defocus = pi3d.Defocus()
mykeys = pi3d.Keyboard()
action = ''
move_steps=0  # à quelle étape en est de la transition - technique utilisée pour le défilement horizontal et le défilement vertical
move_steps_cat=0 # à quelle étape en est de la transition des catégories
move_steps_media=0 # à quelle étape en est de la transition des médias
#mode = 'selection' # 3 modes possibles : selection / categorie / souscategorie
Medias=[]
NextMedias=[]


#taille=10

distance_mediax = 20 # distance horizontale entre les images
distance_mediay = 10 # distance verticale entre les images en cours et les prochaines images
distance_mediaz = 20 # distance verticale entre l'image sélectionnée et les autres images
recul=40 # recul de la caméra
#recul=80

distance=20 # coefficient général pour l'affichage des catégories
distance_caty=0.7
distance_catz=0.08
nb_step_cat=10 # nombre de steps pour passer d'une catégorie à une autre
nb_step_souscat=10 # nombre de steps pour passer d'une sous catégorie à une autre
nb_step_media=10 # nombre de steps pour paser d'un média à un autre - déplacement horizontal
nb_step_groupe_media=10 # nombre de steps pour paser d'un groupe de médias à un autre - déplacement vertical


CAMERA=pi3d.Camera.instance()
CAMERA.position((0,0,-recul))

hand = pi3d.Model(file_string='hand.obj', name='hand') # image de la main
hand.set_shader(SHADER)

sprite = pi3d.ImageSprite("PAD.png", SHADER, w=10.0, h=6.0) # image de la tablette



# Initialisation de la fleche
lfleche = 0.10 # largeur de la fleche
hfleche = 0.125 # hauteur de la fleche
fleche = pi3d.Lines(vertices=[[0, hfleche/4, 0],[2*lfleche/3, hfleche/4 , 0],[2*lfleche/3, hfleche/2, 0],[lfleche,0,0],[2*lfleche/3, -hfleche/2, 0],[2*lfleche/3, -hfleche/4, 0],[0, -hfleche/4, 0],[0, hfleche/4, 0]],x=0, y=0, z=0, material=(1.0,0.8,0.05),line_width=4)
fleche.position(0.27,0,-39)
fleche.shader = pi3d.Shader("mat_flat")

# Initialisation du cadre pour la catégorie en cours
lcadre = 0.5
hcadre = 0.125
cadre = pi3d.Lines(vertices=[[-lcadre/2, -hcadre/2, 0],[-lcadre/2, hcadre/2 , 0],[lcadre/2, hcadre/2, 0],[lcadre/2,-hcadre/2,0],[-lcadre/2, -hcadre/2, 0]],x=0, y=0, z=0, material=(1.0,0.8,0.05),line_width=4)
cadre.position(0,0,-39)
cadre.shader = pi3d.Shader("mat_flat")

refresh_media = True # indique que la liste des médias doit être mise à jour
refresh_next_media = False

action = "InitialiserAffichage"
mode='selection' # mode a 3 valeurs possibles : selection / categorie / souscategorie
while DISPLAY.loop_running():
  
  """ Liste des actions
  
  InitialiserAffichage
  
  AfficherSelection
  DroiteSelection
  GaucheSelection
  
  AfficherCategories
  HautCategories
  BasCategories
  
  AfficherSousCategories
  HautSousCategories
  BasSousCategories
  QuitterSousCategories
  
  """
  
  # Gestion du clavier
  k = mykeys.read()
  if k >-1:
    #print(k)
    if action=='':
      if k == 102:    # F : droite
        if (mode=='selection') and (current_media < nb_medias-1):
          action='DroiteSelection'
          init_droite_selection = True
        elif (mode=='categorie') and (len(sous_categories[current_cat]) > 1): # la catégorie contient plusieurs sous catégories
          action='AfficherSousCategories'
          init_afficher_souscategories = True
          mode='souscategorie'
        elif (mode=='categorie') and (len(sous_categories[current_cat]) <= 1): # la catégorie contient 0 ou 1 sous catégorie
          mode='selection'
        elif (mode=='souscategorie'):
          mode='selection'
        # si mode = souscategorie, ne rien faire
        
      elif k == 115:  # S : gauche
        if (mode=='selection') and (current_media > 0):
          action='GaucheSelection'
          init_gauche_selection = True
        elif mode=='categorie':
          action='AfficherSelection'
          init_afficher_selection = True
          mode='selection'
        elif mode=='souscategorie':
          action = 'QuitterSousCategories'
          init_quitter_souscategories=True
          mode='categorie'
      
      elif k == 101:  # E : haut
        if mode=='selection':
          action='AfficherCategories'
          init_afficher_categories=True
          mode='categorie'
        elif (mode=='categorie') and (current_cat < nb_cats-1):
          action = 'HautCategories'
          init_haut_categories = True
        elif (mode=='souscategorie') and (current_souscat < nb_souscats-1):
          action='HautSousCategories'
          init_haut_souscategories=True

      elif k == 100:  # D : Bas
        if mode=='selection':
          action='AfficherCategories'
          init_afficher_categories=True
          mode='categorie'
        elif (mode=='categorie') and (current_cat > 0):
          action = 'BasCategories'
          init_bas_categories = True
        elif (mode=='souscategorie') and (current_souscat > 0):
          action='BasSousCategories'
          init_bas_souscategories=True
          
    if k == 27:
      mykeys.close()
      if Blur:
        defocus.delete_buffers()
      DISPLAY.destroy()
      break
  
 
 
  
  # Gestion des actions

  ######################################################################
  
  if action == 'InitialiserAffichage':
    #current_media=1 # indice du premier média à afficher
    #current_cat=1 # indice de la première catégorie à afficher
    current_cat=0 # indice de la première catégorie à afficher
    current_souscat=-1 # indice de la sous-catégorie à afficher, -1 pour afficher toutes les sous-catégories
    nb_souscats=0
    
    #Initialiser les catégories
    cats=[]
    i=0
    for categorie in categories:
      x=0
      y=(i-current_cat)*distance_caty
      z=-distance*(1.8-(abs(i-current_cat)*distance_catz))
      print("z=")
      print(z)
      a=pi3d.String(font=pi3d.Font("/home/pi/Documents/pi3d_demos/fonts/NotoSerif-Regular.ttf", (255, 255, 255, 255)), string=categorie, x=x, y=y, z=z)
      a.set_shader(SHADER)
      cats.append(a)
      i=i+1
      
    # Initialiser Medias
    Medias=[]
    for cm in CMedias:
      if categories[current_cat] == cm.cat:
        if current_souscat == -1:
          Medias.append(cm.media)
        elif cm.souscat in sous_categories[current_souscat]:
          Medias.append(cm.media)
    nb_medias=len(Medias)
          
    action='AfficherSelection' # Après l'initialisation, on affiche la sélection
    init_afficher_selection=True
    
  ######################################################################
  
  if action == 'AfficherSelection':
    if init_afficher_selection:
      # insérer si nécessaire le code à exécuter pour initialiser cette action
      init_afficher_selection=False
      

    # Positionner les médias
    nb_images = len(Medias)
    if nb_images > 1:
      current_media=1 # on prend le deuxième média de la liste
    else:
      current_media=0 # on prend le média unique de la liste
      
    i=0
    for Media in Medias:
      x=(i-1)*distance_mediax
      y=0
      if i == current_media:
        z=-distance_mediaz
      else:
        z=0
      Media.position(x,y,z)
      i=i+1
      
    action=''
  

  ######################################################################    
  
  if action == 'DroiteSelection':
    if init_droite_selection:
      move_steps_media=1
      init_droite_selection=False
      
    if move_steps_media <= nb_step_media:
      i=0
      while (i < len(Medias)):
        if (i > current_media -3) and (i < current_media + 3):
          Media = Medias[i]
          x=(i-current_media-move_steps_media/nb_step_media)*distance_mediax
          y, z = 0, 0
          if i == (current_media+1):
            z=-(move_steps_media/nb_step_media)*distance_mediaz
          elif i == current_media:
            z=-(1-move_steps_media/nb_step_media)*distance_mediaz
          Media.position(x,y,z)
        i=i+1
    if move_steps_media == nb_step_media:
      action = ''
      current_media = current_media + 1 
    else:
      move_steps_media=move_steps_media+1
        
  ######################################################################
  
  if action == 'GaucheSelection':
    if init_gauche_selection:
      move_steps_media=1
      init_gauche_selection=False
      
    if move_steps_media <= nb_step_media:
      i=0
      while (i < len(Medias)):
        if (i > current_media -3) and (i < current_media + 3):
          Media = Medias[i]
          x=(i-current_media+move_steps_media/nb_step_media)*distance_mediax
          y, z = 0, 0
          if i == (current_media-1):
            z=-(move_steps_media/nb_step_media)*distance_mediaz
          elif i == current_media:
            z=-(1-move_steps_media/nb_step_media)*distance_mediaz
          Media.position(x,y,z)
        i=i+1

    if move_steps_media == nb_step_media:
      action = ''
      current_media = current_media - 1 
    else:
      move_steps_media=move_steps_media+1
        
    
  ######################################################################
  
  if action=='AfficherCategories':
    if init_afficher_categories:
      print('init_afficher_categories')
      cat = cats[current_cat]
      cat.position(0,0,-distance*1.8)
      init_afficher_categories=False
    action=''

  ######################################################################
  
  if action=='AfficherSousCategories':
    if init_afficher_souscategories:
      print('init_afficher_souscategories')
      current_souscat = 1
      
      #Initialiser les sous catégories
      souscats=[]
      i=0
      for souscategorie in sous_categories[current_cat]:
        x=0
        y=(i-current_souscat)*distance_caty
        z=-distance*(1.8-(abs(i-current_souscat)*distance_catz))
        #z=-distance*1.8
        a=pi3d.String(font=pi3d.Font("/home/pi/Documents/pi3d_demos/fonts/NotoSerif-Regular.ttf", (255, 255, 255, 255)), string=souscategorie, x=x, y=y, z=z)
        a.set_shader(SHADER)
        souscats.append(a)
        i=i+1
      nb_souscats = len(souscats)
        
      # Initialiser NextMedias
      NextMedias=[]
      for cm in CMedias:
        if (categories[current_cat] == cm.cat) and (sous_categories[current_cat][current_souscat] == cm.souscat):
          NextMedias.append(cm.media)
      if (len(NextMedias)>1):
        next_current_media=1
      else:
        next_current_media=0
        
      move_steps=0
      init_afficher_souscategories=False
      
    # Afficher la transition des médias
    transitionMediaBas(move_steps, nb_step_groupe_media)
    
    # Afficher la transition à gauche de la catégorie
    cat = cats[current_cat]
    x=-2*move_steps/nb_step_groupe_media
    y=move_steps/nb_step_groupe_media
    z=-distance*1.8
    cat.position(x,y,z)
  
    
    if move_steps < nb_step_groupe_media:
      move_steps=move_steps+1
    else:
      current_media = next_current_media
      Medias = NextMedias
      nb_medias=len(Medias)
      NextMedias = []
      action = ''

  ######################################################################
  
  if action == 'QuitterSousCategories':
    if init_quitter_souscategories:
      print('init_quitter_souscategories')
      print(current_media)
      
      cat = cats[current_cat]
      cat.position(0,0,-distance*1.8)
      
      # Initialiser NextMedias
      NextMedias=[]
      for cm in CMedias:
        if (categories[current_cat] == cm.cat):
          NextMedias.append(cm.media)
      if (len(NextMedias)>1):
        next_current_media=1
      else:
        next_current_media=0
        
      move_steps=0
      init_quitter_souscategories=False
      
    # Afficher la transition des médias
    transitionMediaBas(move_steps, nb_step_groupe_media)
    
    if move_steps < nb_step_groupe_media:
      move_steps=move_steps+1
    else:
      current_media = next_current_media
      current_souscat = -1
      Medias = NextMedias
      nb_medias=len(Medias)
      NextMedias = []
      action = ''
      
  ######################################################################
  
  if action == 'HautCategories':
    if init_haut_categories:
      print("init_haut_categories")
      move_steps_cat=0
      print("nb_souscats=")
      print(nb_souscats)
      next_cat = current_cat+1
      
      # Initialiser NextMedias
      NextMedias=[]
      for cm in CMedias:
        if categories[next_cat] == cm.cat:
          NextMedias.append(cm.media)
      if (len(NextMedias)>1):
        next_current_media=1
      else:
        next_current_media=0

      init_haut_categories=False
      
    if move_steps_cat <= nb_step_cat:
      i=0
      for cat in cats:
        y=(i-current_cat-move_steps_cat/nb_step_cat)*distance_caty
        z=-distance*(1.8-(abs(i-current_cat-move_steps_cat/nb_step_cat)*distance_catz))
        print("z=")
        print(z)
        cat.position(0,y,z)
        i=i+1
        
      #print("transitionMediaBas")
      transitionMediaBas(move_steps_cat, nb_step_cat)
        
    if move_steps_cat < nb_step_cat:
      move_steps_cat=move_steps_cat+1
    else:
      #print("fleche.draw")
      #pos_z = -distance*(1.8-distance_catz)-2
      #print("pos_z=")
      #print(pos_z)
      #fleche.position(0,0,pos_z)
      #fleche.draw()
      current_cat = next_cat
      current_media = next_current_media
      Medias = NextMedias
      nb_medias=len(Medias)
      nb_souscats = len(sous_categories[current_cat])
      NextMedias = []
      action = ''
      
    
  ######################################################################
      
  if action == 'HautSousCategories':
    if init_haut_souscategories:
      print("init_haut_souscategories")
      move_steps_souscat=0
      next_souscat = current_souscat+1
      
      # Initialiser NextMedias
      NextMedias=[]
      for cm in CMedias:
        if (categories[current_cat] == cm.cat) and (sous_categories[current_cat][next_souscat] == cm.souscat):
          NextMedias.append(cm.media)
      if (len(NextMedias)>1):
        next_current_media=1
      else:
        next_current_media=0

      init_haut_souscategories=False
      
    if move_steps_souscat <= nb_step_souscat:
      i=0
      for souscat in souscats:
        y=(i-current_souscat-move_steps_souscat/nb_step_cat)*distance_caty
        z=-distance*(1.8-(abs(i-current_souscat-move_steps_souscat/nb_step_souscat)*distance_catz))
        souscat.position(0,y,z)
        i=i+1
        
      #print("transitionMediaBas")
      transitionMediaBas(move_steps_souscat, nb_step_souscat)
        
    if move_steps_souscat < nb_step_souscat:
      move_steps_souscat=move_steps_souscat+1
    else:
      current_souscat = next_souscat
      current_media = next_current_media
      Medias = NextMedias
      nb_medias=len(Medias)
      NextMedias = []
      action = ''
      
  ######################################################################
      
  if action == 'BasCategories':
    if init_bas_categories:
      print("init_bas_categories")
      move_steps_cat=0
      print("move_steps_cat=0")
      next_cat = current_cat-1
      
      # Initialiser NextMedias
      NextMedias=[]
      for cm in CMedias:
        if categories[next_cat] == cm.cat:
          NextMedias.append(cm.media)
      if (len(NextMedias)>1):
        next_current_media=1
      else:
        next_current_media=0

      init_bas_categories=False
      
    if move_steps_cat <= nb_step_cat:
      i=0
      for cat in cats:
        y=(i-current_cat+move_steps_cat/nb_step_cat)*distance_caty
        z=-distance*(1.8-(abs(i-current_cat+move_steps_cat/nb_step_cat)*distance_catz))
        print("z=")
        print(z)
        cat.position(0,y,z)
        i=i+1
        
      #print("transitionMediaHaut")
      transitionMediaHaut(move_steps_cat, nb_step_cat)
        
    if move_steps_cat < nb_step_cat:
      move_steps_cat=move_steps_cat+1
    else:
      current_cat = next_cat
      current_media = next_current_media
      Medias = NextMedias
      nb_medias=len(Medias)
      nb_souscats = len(sous_categories[current_cat])
      NextMedias = []
      action = ''
  
  ######################################################################
      
  if action == 'BasSousCategories':
    if init_bas_souscategories:
      print("init_bas_souscategories")

      move_steps_souscat=0
      next_souscat = current_souscat-1
      print("next_souscat=")
      print(next_souscat)
      
      # Initialiser NextMedias
      NextMedias=[]
      for cm in CMedias:
        if (categories[current_cat] == cm.cat) and (sous_categories[current_cat][next_souscat] == cm.souscat):
          NextMedias.append(cm.media)
      if (len(NextMedias)>1):
        next_current_media=1
      else:
        next_current_media=0

      init_bas_souscategories=False
      
    if move_steps_souscat <= nb_step_souscat:
      i=0
      for souscat in souscats:
        y=(i-current_souscat+move_steps_souscat/nb_step_souscat)*distance_caty
        z=-distance*(1.8-(abs(i-current_souscat+move_steps_souscat/nb_step_souscat)*distance_catz))
        souscat.position(0,y,z)
        i=i+1
        
      #print("transitionMediaHaut")
      transitionMediaHaut(move_steps_souscat, nb_step_souscat)
        
    if move_steps_souscat < nb_step_souscat:
      move_steps_souscat=move_steps_souscat+1
    else:
      current_souscat = next_souscat
      current_media = next_current_media
      Medias = NextMedias
      nb_medias=len(Medias)
      NextMedias = []
      action = ''
  
  ######################################################################
  
  # Affichage des objets    
  
  # Affichage de la fleche et du cadre si mode = catégorie
  if (mode == 'categorie') and (action == ''):
    fleche.draw()
  
  
  if mode=='categorie':
    cadre.draw()
    for cat in cats:
      cat.draw()
      
  
  if mode=='souscategorie':
    cadre.draw()
    cat=cats[current_cat]
    cat.draw()
    for souscat in souscats:
      souscat.draw()
    if action=='':
      fleche.draw()
      
 
  if mode == 'categorie' and Blur:
    defocus.start_blur()
  
  
  # Afficher 2 médias avant et 2 médias après le media courant
  i=0
  while (i < len(Medias)):
    if (i > current_media -2) and (i < current_media + 2):
      Media = Medias[i]
      Media.draw()
    i=i+1
    
  
  # idem pour Next Medias
  i=0
  while (i < len(NextMedias)):
    if (i > next_current_media -2) and (i < next_current_media + 2):
      Media = NextMedias[i]
      Media.draw()
    i=i+1
    
  
  if Fog:
    if move_steps_cat==2:
      print("Fog")
    if (mode == 'categorie') or (mode == 'souscategorie'):
      for i in range(len(Medias)):
        if i==current_media:
          Medias[i].set_fog((0,0,0,0.9),30.0)
        else:
          Medias[i].set_fog((0,0,0,0.92),40.9)
      for i in range(len(NextMedias)):
        if i==next_current_media:
          NextMedias[i].set_fog((0,0,0,0.9),30.0)
        else:
          NextMedias[i].set_fog((0,0,0,0.92),40.9)
     
      #if current_media > 1:
        #Medias[current_media-2].set_fog((0,0,0,0.92),40.9)
      #if current_media > 0:
        #Medias[current_media-1].set_fog((0,0,0,0.92),40.9)
      #Medias[current_media].set_fog((0,0,0,0.9),30.0)
      #if current_media < nb_images-1:
        #Medias[current_media+1].set_fog((0,0,0,0.92),40.9)
      #if current_media < nb_images-2:
        #Medias[current_media+2].set_fog((0,0,0,0.92),40.9)

    else:
      for Media in Medias:
        Media.set_fog((0,0,0,1),100)
      for Media in NextMedias:
        Media.set_fog((0,0,0,1),100)

  if Blur:
    if move_steps_cat==2:
      print("Blur")
    if mode == 'categorie':
      defocus.end_blur()
      for Media in Medias:
        defocus.blur(Media, -distance/2, distance, 2) # if 4,9,5 : 4 is focal distance, >= 9 distance will get 5 x blurring, nearer than focus also blurs
      for Media in NextMedias:
        defocus.blur(Media, -distance/2, distance, 2) # if 4,9,5 : 4 is focal distance, >= 9 distance will get 5 x blurring, nearer than focus also blurs
      fleche.position(0,0,-39)
      fleche.draw()
  
  """
  hand.rotateToY(110)
  #hand.rotateIncY(3)
  hand.rotateToX(-80)
  #hand.rotateIncX(3)
  hand.rotateToZ(10)
  #hand.rotateIncZ(1)
  hand.position(10,-7+move_steps/6,-19)
  #hand.position(0,-1,-32)
 
  
  
  #hand.position(10,-6+move_steps/2,40)
  
  hand.draw()

  #sprite.rotateToX(20)
  sprite.position(14,-7.5,-10)
  sprite.draw()
  """
  """
  if (refresh_media):
    # Initialiser Medias
    Medias=[]
    for cm in CMedias:
      if categories[current_cat] == cm.cat:
        if current_souscat == -1:
          Medias.append(cm.media)
        elif cm.souscat in sous_categories[current_souscat]:
          Medias.append(cm.media)
          
    # Positionner les médias
    nb_images = len(Medias)
    if nb_images > 1:
      current_media=1 # indice du premier média à afficher
    else:
      current_media=0
      
    i=0
    for Media in Medias:
      x=(i-1)*distance_mediax
      y=0
      if i == current_media:
        z=-distance_mediaz
      else:
        z=0
      Media.position(x,y,z)
      i=i+1
      
    refresh_media = False
    #print(categories[current_cat])
    #print(nb_images)
        

  if (refresh_next_media):
    # Initialiser NextMedias
    NextMedias=[]
    for cm in CMedias:
      if categories[next_cat] == cm.cat:
        NextMedias.append(cm.media)
    print("Initialisation de NextMedia")
    print(categories[next_cat])
    print(len(NextMedias))
        
    # Positionner les NextMedias
    nb_next_images = len(NextMedias)
    if nb_next_images > 1:
      next_current_media=1 # indice du premier média à afficher
    else:
      next_current_media=0
      
    i=0
    for Media in NextMedias:
      x=(i-1)*distance_mediax
      if next_cat > current_cat: # positionner les next medias au dessus
        y=distance_mediay
      else: # positionner les next medias en dessous
        y=-distance_mediay
      if i == next_current_media:
        z=-distance_mediaz
      else:
        z=0
      Media.position(x,y,z)
      i=i+1
      
    refresh_next_media = False
  """
 
