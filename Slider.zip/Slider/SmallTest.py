x = 1
y = 2

def foo2():
	global y
	y = 10
	x = 20
	print('y in foo2 : ', y)
	z = y
	print('z in foo2 : ', z)
	
def foo():
	global x
	print(y)
	print('y in foo: ',y)
	y = 20
	print('y in foo: ',y)
	
foo2()
print('x : ',x)
print('y : ',y)
