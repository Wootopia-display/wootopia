#!/usr/bin/python
#from __future__ import absolute_import, division, print_function, unicode_literals

""" Example showing what can be left out. ESC to quit"""
#import sys
#sys.path.insert(1, '/home/pi/Documents/pi3d-develop/pi3d')
import pi3d
import os


Repertoire='/home/pi/Documents/Slider/Chaussures Hommes-sport'
Blur=True
Blur=False
Fog=True

images=os.listdir(Repertoire)
nb_images=len(images)
#print(images)

BACKGROUND = (0, 0, 0, 0.0)

#DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=10, display_config=pi3d.DISPLAY_CONFIG_FULLSCREEN)
#DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=40, w=1000, h=800, use_glx=True)
DISPLAY = pi3d.Display.create(background=BACKGROUND, frames_per_second=40, w=1400, h=800)
SHADER = pi3d.Shader("uv_flat")
if Blur:
  defocus = pi3d.Defocus()
mykeys = pi3d.Keyboard()
action = ''
move_steps=0
mode = 'selection'
Medias=[]
categories=['Chaussures Hommes-collections hiver','Chaussures Hommes-sport','Chaussures Hommes-ville',
  'Chaussures Femmes-ville','Chaussures Femmes-collections hiver','Chaussures Femmes-sport',
  'Chaussures Enfants-ville','Chaussures Enfants-collections hiver','Chaussures Enfants-sport']
nb_cats=len(categories)

#taille=10
distance=20
recul=40
#recul=80
step=0.5
step=5
distance_caty=0.7
distance_catz=0.08
nb_step_cat=10

CAMERA=pi3d.Camera.instance()
CAMERA.position((0,0,-recul))

hand = pi3d.Model(file_string='hand.obj', name='hand')
hand.set_shader(SHADER)

sprite = pi3d.ImageSprite("PAD.png", SHADER, w=10.0, h=6.0)

W=1
D=1
HT=1
axes = pi3d.Lines(vertices=[[2.0*W, 0.0, 0.0], [0.0, 0.0, 0.0],
                  [0.0, 2.0*HT, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 2.0*D]],
                  line_width=3, x=-W/2.0, z=-D/2.0)
axes.set_shader(SHADER)


#print(nb_images)

current_media=1
current_cat=1

i=0
for image in images:
  #TEXTURE = pi3d.Texture(Repertoire + '/' + image)
  x=(i-1)*distance
  y=0
  if i == current_media:
    z=-distance
  else:
    z=0
  Media = pi3d.ImageSprite(Repertoire + '/' + image, shader=SHADER, w=13, h=9.3, x=x, y=y, z=z)
  i=i+1
  Medias.append(Media)

cats=[]
i=0
for categorie in categories:
  x=0
  y=(i-current_cat)*distance_caty
  z=-distance*(1.8-(abs(i-current_cat)*distance_catz))
  #z=-distance*1.8
  a=pi3d.String(font=pi3d.Font("/home/pi/Documents/pi3d_demos/fonts/NotoSerif-Regular.ttf", (255, 255, 255, 255)), string=categorie, x=x, y=y, z=z)
  a.set_shader(SHADER)
  cats.append(a)
  i=i+1

while DISPLAY.loop_running():
  # Gestion du clavier
  k = mykeys.read()
  if k >-1:
    #print(k)
    if action=='':
      if k == 102:    # F : droite
        if mode=='categorie':
          mode='selection'
        elif current_media < nb_images-1:
          action = 'droite'
      elif k == 115:  # S : gauche
        if mode=='categorie':
          mode='selection'
        elif current_media > 0:
          action = 'gauche'
      elif k == 101:  # E : haut
        if mode=='selection':
          mode='categorie'
        elif current_cat < nb_cats-1:
          action = 'haut'
          move_steps=1
      elif k == 100:  # D : Bas
        if mode=='selection':
          mode='categorie'
        elif current_cat > 0:
          action = 'bas'
          move_steps=1
    if k == 27:
      mykeys.close()
      if Blur:
        defocus.delete_buffers()
      DISPLAY.destroy()
      break
  
  # Gestion des actions
  if action == 'droite':  
    if (Medias[current_media+1].x() > 0):
      i=0
      for Media in Medias:
        if i==current_media:
          Media.translate(-step,0,step)
        elif i==current_media+1:
          Media.translate(-step,0,-step)
        else:
           Media.translate(-step,0,0)
        i=i+1 
    else:
      action = ''
      if current_media < nb_images:
        current_media = current_media + 1 
      
  if action == 'gauche':   
    if (Medias[current_media-1].x() < 0):
      i=0
      for Media in Medias:
        if i==current_media-1:
          Media.translate(step,0,-step)
        elif i==current_media:
          Media.translate(step,0,step)
        else:
          Media.translate(step,0,0)
        i=i+1
    else:
      action = ''
      if  current_media > 0 :
        current_media = current_media - 1 
    
  if action == 'haut':
    if move_steps <= nb_step_cat:
      i=0
      for cat in cats:
        y=(i-current_cat-move_steps/nb_step_cat)*distance_caty
        z=-distance*(1.8-(abs(i-current_cat-move_steps/nb_step_cat)*distance_catz))
        cat.position(0,y,z)
        i=i+1
    if move_steps == nb_step_cat:
      action = ''
      current_cat = current_cat + 1 
    else:
      move_steps=move_steps+1
  if action == 'bas':
    if move_steps <= nb_step_cat:
      i=0
      for cat in cats:
        y=(i-current_cat+move_steps/nb_step_cat)*distance_caty
        z=-distance*(1.8-(abs(i-current_cat+move_steps/nb_step_cat)*distance_catz))
        cat.position(0,y,z)
        i=i+1
    if move_steps == nb_step_cat:
      action = ''
      current_cat = current_cat - 1
      move_steps=0
    else:
      move_steps=move_steps+1
  
  
  # Affichage des objets      
  if mode=='categorie':
    for cat in cats:
      cat.draw()
   
  if mode == 'categorie' and Blur:
    defocus.start_blur()

  if current_media > 1:
    Medias[current_media-2].draw()
  if current_media > 0:
    Medias[current_media-1].draw()
  Medias[current_media].draw()
  if current_media < nb_images-1:
    Medias[current_media+1].draw()
  if current_media < nb_images-2:
    Medias[current_media+2].draw()
  
  if Fog:
    if mode == 'categorie':
      if current_media > 1:
        Medias[current_media-2].set_fog((0,0,0,0.92),40.9)
      if current_media > 0:
        Medias[current_media-1].set_fog((0,0,0,0.92),40.9)
      Medias[current_media].set_fog((0,0,0,0.9),30.0)
      if current_media < nb_images-1:
        Medias[current_media+1].set_fog((0,0,0,0.92),40.9)
      if current_media < nb_images-2:
        Medias[current_media+2].set_fog((0,0,0,0.92),40.9)
    else:
      for Media in Medias:
        Media.set_fog((0,0,0,1),100)

  if Blur:
    if mode == 'categorie':
      defocus.end_blur()
      for Media in Medias:
          defocus.blur(Media, -distance/2, distance, 2) # if 4,9,5 : 4 is focal distance, >= 9 distance will get 5 x blurring, nearer than focus also blurs

  hand.rotateToY(110)
  #hand.rotateIncY(3)
  hand.rotateToX(-80)
  #hand.rotateIncX(3)
  hand.rotateToZ(10)
  #hand.rotateIncZ(1)
  hand.position(10,-7+move_steps/6,-19)
  #hand.position(0,-1,-32)
  
  
  
  #hand.position(10,-6+move_steps/2,40)
  
  axes.draw()
  
  hand.draw()

  sprite.rotateToX(20)
  sprite.position(14,-7.5,-10)
  sprite.draw()
